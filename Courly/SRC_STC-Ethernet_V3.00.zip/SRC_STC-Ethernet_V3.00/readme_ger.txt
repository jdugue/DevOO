--------------------------Readme---------------------------

SRC-Ethernet

Version	2.0

Versionen �ber 2.0 sind kompatibel mit Ger�ten, welche ab 2007 
gefertigt worden.

Stand:	19.06.2007


--------------------------Inhalt---------------------------

1.	Software Features
1.1	Einstellungen
1.2	Sensoren
1.3	Daten loggen
1.4	Speichern
1.5	Drucken
1.6 	Hilfe
2.	Systemvoraussetzungen
3.	Hinweise zur Installation
4.	Support
5.	Endbenutzervereinbarung

-----------------------------1.---------------------------
1.	Software Features

1.1 Einstellungen
Im Reiter "Einstellungen" werden die am Ethernet aktuell 
angeschlossenen Funkempf�nger mit ihren dazugeh�rigen IP-
Adressen angezeigt. 

1.2 Sensoren
Der Reiter "Sensoren" ist zum Konfigurieren der Sensor 
Adressen (Sensor ID). 

1.3 Daten loggen
Im Reiter "Daten loggen" steht eine einfache Diagnose-
funktion zur Verf�gung, mit der Sensoren mitgeloggt werden 
k�nnen.

1.4 Speichern
Im Reiter "Einstellungen" und "Sensoren" k�nnen die 
Netzwerkeinstellungen, Beschreibung und die 
Sensorkonfigurationen des Funkempf�ngers gespeichert werden. 
Geloggte Daten k�nnen im Reiter "Daten loggen" gespeichert 
werden.
	
1.5 Drucken
Im Reiter "Einstellungen" und "Sensoren" k�nnen die 
Netzwerkeinstellungen, Beschreibung und die 
Sensorkonfigurationen des Funkempf�ngers ausgedruckt werden. 
Geloggte Daten k�nnen im Reiter "Daten loggen" ausgedruckt 
werden.

1.6 Hilfe
Eine Hilfe zum Programm kann �ber den Men�punkt "Hilfe" 
abgrufen werden. Um die Hilfe �ffnen zu k�nnen ben�tigen Sie 
den Acrobat Reader.
Informationen zu den Sensoren finden Sie in den 
Produktspezifischen Datenbl�ttern. 


-----------------------------2.----------------------------

2. 	Systemvoraussetzungen

Betriebsystem:  Windows 9x, Me, Xp, Nt, 2000, XP
CPU & RAM:  es werden keine besonderen Anforderungen gestellt



-----------------------------3.----------------------------

3.	Hinweise zur Installation

Sie m�ssen �ber Administratorrechte verf�gen, um die Software 
Fehlerfrei installieren und nutzen zu k�nnen.

Versionen �ber 2.0 sind kompatibel mit Ger�ten, welche ab 2007 
gefertigt worden.

----------------------------4.-----------------------------

4.	Support

Sollten Sie Fehler festgestellt, Fragen oder Anregugen haben, 
dann k�nnen Sie sich gerne mit uns in Verbindung setzen unter:

	eMail:  email@Thermokon.de
	Tel. :  +49 2772/6501-0
	Fax  :  +49 2772/6501-400
   

Das Thermokon Team w�nscht Ihnen viel Spass beim arbeiten!

 
-----------------------------5.----------------------------

5. Endbenutzervereinbarung

   Der Endbenutzer ist berechtigt:
      
   - Die Thermokon- Applikationsprogramme in Verbindung mit
     Thermokon- Produkten zu nutzen.

   - Die Thermokon- Applikationsprogramme bzw. die Software 
     als Ganzes zu kopieren, unter der Voraussetzung, dass 
     eine Fehlerfreiheit der Kopien sichergestellt wird und 
     eine Ver�nderung der darin enthaltenen Daten 
     ausgeschlossen ist.

   Als Endbenutzer verpflichten Sie sich die Software nur 
   bestimmungsgem�� zu verwenden.


   Haftung
   
   Die Thermokon Sensortechnik GmbH �bernimmt keine Haftung 
   f�r Sch�den die durch Nutzung der Software entstehen.	






























