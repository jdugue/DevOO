--------------------------Readme---------------------------

SRC-Ethernet

Version	2.0

Versions above 2.0 are compatible with devices, which are 
built from 2007.

Issued:	19.06.2007

--------------------------Content---------------------------

1.	Software Features
1.1	Adjustments
1.2	Sensors
1.3	Logging of Data
1.4	Data Storage
1.5	Print
1.6 	Help
2.	System Prerequisites 
3.	Installation Advice
4.	Support
5.	End User Agreement

-----------------------------1.---------------------------

1.	Software Features

1.1 Adjustments
In the rider "Adjustments" the radio receivers currently 
connected to the Ethernet are displayed along with its 
corresponding IP addresses. 

1.2 Sensors
The rider "Sensors" is used for the configuration of the 
sensor addresses (Sensor ID). 

1.3 Logging of Data 
In the rider "Logging of Data" a simple diagnosis function 
is available by which sensors can be logged.

1.4 Data Storage
In the riders "Adjustments" and "Sensors" the network 
adjustments, device descriptions and the sensor configuration 
of the radio receiver can be stored. In the rider 
"Logging of Data", it is possible to store the data logged.
	
1.5 Print
In the rider "Adjustments" and "Sensors" the network 
adjustments, device descriptions and the sensor configuration 
of the radio receiver can be print. In the rider
"Logging of Data" the diagram of the data logged is printed.

1.6 Help
Help relating to the program can be called off via the
menu point "Help". In order to be able to open the help, 
the Acrobat Reader is needed. Information on the sensors can 
be found in the respective product data sheets. 


-----------------------------2.----------------------------

2. 	System Prerequisites 


Operating System:  Windows 9x, Me, Xp, Nt, 2000, XP
CPU & RAM:  no special requirements are needed 


-----------------------------3.----------------------------

3.	Installation Advice

In order to install and run the software successfully you 
must dispose of administrator rights.

Versions above 2.0 are compatible with devices, which are 
built from 2007.

----------------------------4.-----------------------------

4.	Support

If any malfunctions are found or if you have any questions 
or suggestions, please do not hesitate to contact us:

	eMail:  email@Thermokon.de
	Tel. :  +49 2772/6501-0
	Fax  :  +49 2772/6501-400
   

The Thermokon Team hopes you will enjoy working with 
the software!

 
-----------------------------5.----------------------------

5. End User Agreement

   The end user is entitled to:
      
   * use the Thermokon- Application programmes in 
     connection with Thermokon products.

   * copy the Thermokon - Application programmes respectively 
     the software as a whole, provided it is guaranteed that 
     the copies are faultlessly and a change of the data 
     contained therein is excluded.

   As the end user you oblige yourself to use the software 
   only for this proper application, as agreed. 

   Liability
   
   The Thermokon Sensortechnik GmbH is not liable for any 
   damages arising by the use of this software. 




























